//
// Created by ltt on 16-11-3.
//

#ifndef TEST_DETECT_H
#define TEST_DETECT_H

#endif //TEST_DETECT_H

#include <opencv2/opencv.hpp>

bool facedetect(cv::Mat frame,cv::Rect &Box);