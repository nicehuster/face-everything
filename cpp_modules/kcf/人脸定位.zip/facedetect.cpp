//
// Created by ltt on 16-11-3.
//

#include <opencv2/opencv.hpp>
#include <string>

bool facedetect(cv::Mat frame,cv::Rect &Box)
{
    cv::Mat gray;
    cv::cvtColor(frame,gray,CV_BGR2GRAY); //转换成灰度图，因为harr特征从灰度图中提取
    equalizeHist(gray,gray);  //直方图均衡行

    std::string xmlPath="/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_default.xml";
    //std::string xmlPath="/usr/local/share/OpenCV/haarcascades/haarcascade_eye_tree_eyeglasses.xml";
    //std::string xmlPath="/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_alt.xml";
    cv::CascadeClassifier ccf;   //创建分类器对象
    if(!ccf.load(xmlPath))   //加载训练文件
    {
        std::cout<<"不能加载指定的xml文件"<<std::endl;
    }
    std::vector<cv::Rect> faces;  //创建一个容器保存检测出来的脸
    ccf.detectMultiScale(gray,faces,1.1,3,0,cv::Size(100,100),cv::Size(350,350)); //检测人脸

    int biggstFaceArea = 0;

    for(cv::vector<cv::Rect>::const_iterator iter=faces.begin();iter!=faces.end();iter++)
    {
        if((*iter).width * (*iter).height > biggstFaceArea)
        {
            Box = *iter;
            biggstFaceArea = (*iter).width * (*iter).height;
        }
    }

    return faces.size() != 0;
}